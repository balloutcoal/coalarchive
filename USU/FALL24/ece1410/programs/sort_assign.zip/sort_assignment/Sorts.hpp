
#ifndef SORTS_HPP
#define SORTS_HPP
 
class Sorts
{
  public:
  void bubble(int*, int);
  
  void insertion(int*, int);
  void quick(int*, int);
  
  // Any Other Function you want to declare

  private:

	  // Any Variables you will need
};


// IMPLEMENTATION --- YOUR CODE
#endif